/**
 * Contains the only exposed API of this module which is the entry class to import into Spring.
 * <p>
 * For more information on this module, please refer to
 * <a href="https://www.simplejavamail.org/modules.html#spring-module">Spring support on simplejavamail.org</a>.
 */
package org.simplejavamail.springsupport;