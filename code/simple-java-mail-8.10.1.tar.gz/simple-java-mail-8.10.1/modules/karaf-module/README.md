Compiles simplejavamail into an Apache Karaf feature. 

Usage in Karaf simılar to: 
```
karaf@root()> repo-add mvn:org.simplejavamail/simplejavamail-karaf-feature/<VERSION>/xml/features
karaf@root()> feature:install simplejavamail-karaf-feature
```

