package org.simplejavamail.api.internal.outlooksupport.model;

/**
 * @see OutlookMessage
 */
public interface OutlookAttachment {

}