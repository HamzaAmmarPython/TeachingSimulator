package org.simplejavamail.api.internal.clisupport.model;

public enum CliCommandType {
    send, connect, validate
}
