/**
 * Contains the <a href="https://www.simplejavamail.org/modules.html#navigation">API layer</a>, containing all the
 * public API for working with emails and mailers.
 */
package org.simplejavamail.api;